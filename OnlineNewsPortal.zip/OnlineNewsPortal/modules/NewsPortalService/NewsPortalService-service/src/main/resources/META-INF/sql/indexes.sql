create index IX_789D389D on FBPS_Feedback (companyId);
create index IX_8A5BF331 on FBPS_Feedback (feedbackText[$COLUMN_LENGTH:75$]);
create index IX_B665425F on FBPS_Feedback (groupId);
create index IX_5EFE4FDF on FBPS_Feedback (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_CD474221 on FBPS_Feedback (uuid_[$COLUMN_LENGTH:75$], groupId);