package Com.Greeting.constants;

/**
 * @author LBMHS-ROEHAMPTON PC
 */
public class GreetingPortletKeys {

	public static final String GREETING =
		"Com_Greeting_GreetingPortlet";

}