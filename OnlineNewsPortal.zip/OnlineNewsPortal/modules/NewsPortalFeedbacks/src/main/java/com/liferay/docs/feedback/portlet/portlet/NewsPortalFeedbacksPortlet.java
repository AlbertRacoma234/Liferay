package com.liferay.docs.feedback.portlet.portlet;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.docs.feedback.model.Feedback;
import com.liferay.docs.feedback.portlet.constants.NewsPortalFeedbacksPortletKeys;
import com.liferay.docs.feedback.service.FeedbackLocalServiceUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

/**
 * @author LBMHS-ROEHAMPTON PC
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=NewsPortalFeedbacks",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + NewsPortalFeedbacksPortletKeys.NEWSPORTALFEEDBACKS,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class NewsPortalFeedbacksPortlet extends MVCPortlet {
	
	public void addFeedback(ActionRequest actionrequest, ActionResponse actionresponse) {
		String subject = ParamUtil.getString(actionrequest, "feedbackSub");
		String message = ParamUtil.getString(actionrequest, "feedbackMsg");
		
		System.out.println("Subject is:-" + subject);
		System.out.println("Message is:-" + message);
		
		/** Auto Increment **/
		long feedbackID = CounterLocalServiceUtil.increment();
		/** Create  Feedback Object  **/
		Feedback feedback =	FeedbackLocalServiceUtil.createFeedback(feedbackID);
		/** Insert String Values into Model**/
		
		feedback.setFeedbackSubject(subject);
		feedback.setFeedbackText(message);
		/** Insert String Values into Model**/
		FeedbackLocalServiceUtil.addFeedback(feedback);
		
		System.out.println("feedback has been succesfully Created");
}
}