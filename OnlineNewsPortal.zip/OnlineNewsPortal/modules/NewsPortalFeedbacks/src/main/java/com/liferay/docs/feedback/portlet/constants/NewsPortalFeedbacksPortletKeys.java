package com.liferay.docs.feedback.portlet.constants;

/**
 * @author LBMHS-ROEHAMPTON PC
 */
public class NewsPortalFeedbacksPortletKeys {

	public static final String NEWSPORTALFEEDBACKS =
		"com_liferay_docs_feedback_portlet_NewsPortalFeedbacksPortlet";

}