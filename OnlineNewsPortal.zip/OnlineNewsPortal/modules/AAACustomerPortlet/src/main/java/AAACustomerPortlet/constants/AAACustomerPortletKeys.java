package AAACustomerPortlet.constants;

/**
 * @author LBMHS-ROEHAMPTON PC
 */
public class AAACustomerPortletKeys {

	public static final String AAACUSTOMER =
		"AAACustomerPortlet_AAACustomerPortlet";

}